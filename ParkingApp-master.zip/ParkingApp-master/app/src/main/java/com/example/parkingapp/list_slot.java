package com.example.parkingapp;

public class list_slot {

    String slot;

    list_slot(){

    }

    public list_slot(String slot) {
        this.slot = slot;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }
}
